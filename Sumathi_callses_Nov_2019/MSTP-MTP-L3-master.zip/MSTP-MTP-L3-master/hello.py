import sys
print('value 1:',sys.argv[1])
print('value 2:',sys.argv[2])
print('no of inputs:',len(sys.argv))