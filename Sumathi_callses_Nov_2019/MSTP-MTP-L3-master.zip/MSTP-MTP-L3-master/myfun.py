marks = 130
def predict(x):
    return (x*2)+1
